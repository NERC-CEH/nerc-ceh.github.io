My project
----------
Different types of animal and their traits.